Please install driver first from DRIVER folder by Install.cmd

NOR READER :
be sure jumper cable was connected directly
Run KDW NOR READER and PS4DUMP.bin will be created atomatically

NOR WRITER :
rename your dump to PS4X9.bin , and put in same folder as this tools , 
check your connection cables, and run KDW NOR WRITER, wait for ch
to reading old flash dump, then erase chip, and programmed chip automatically, and verified flashed dump. 

credit flashroom.org for tools, kdwgamestore , tomyrambozha

troubleshoot :
1. if device initialization failure, check your ch driver and or ch is working perfectly without jumper cable installed
2. if fail to read eprom/bios, cek your cable connection

USE THIS TOOL FOR REPAIRING CONSOLE ONLY SUCH AS ; BLOD, NOR CORRUPTION, UART AND OTHER.
DO WITH YOUR OWN RISK . 